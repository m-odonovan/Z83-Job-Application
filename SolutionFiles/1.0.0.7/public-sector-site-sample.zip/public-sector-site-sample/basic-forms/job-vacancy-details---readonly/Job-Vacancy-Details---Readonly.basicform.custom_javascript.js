$(document).ready(function () {
//only if vacancy reference no field is populated
varVacancyRefNo = $('#govc_referenceno').val();
if (varVacancyRefNo != null)
{
    SwapTextForLabel("govc_requirementsdescription");
    SwapTextForLabel("govc_jobpurpose");
    SwapTextForLabel("govc_keyperformanceareas");

  var applyButton = $('<input type="button" class="btn btn-primary" onclick="apply(\''+varVacancyRefNo+'\')" id="applybtn" value="Apply"></input>');
  //var applyButton2 = $('<input type="button" class="btn btn-primary" onclick="apply(\''+varVacancyRefNo+'\')" id="abs2" value="Apply"></input>');
  //get 1st DIV which starts with EntityFormControl i..e this is the form control
  var entityForm = $("div[id^='EntityFormControl']").eq(0);
  if (entityForm != null)
  {
      //entityForm.before(applyButton);
      entityForm.after(applyButton);
  }
}

});

function apply(referenceNo){
  window.location='/app-requirements/?id='+ referenceNo ;
}
//change textarea to label for better UX
function SwapTextForLabel(ControlId) {
  var newObject = document.createElement('label');
  newObject.textContent =  $('#' + ControlId).val();
  $('#' + ControlId).replaceWith(newObject);
  }