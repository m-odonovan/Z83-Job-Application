$(document).ready(function () {
//only if vacancy reference no field is populated
    SwapTextForLink("contoso_procurementrepemail");
});


//change textarea to label for better UX
function SwapTextForLink(ControlId) {
  var newObject = document.createElement('a');
   newObject.textContent = "download tender document";
   newObject.href = "https://goo.com/pdf.pdf";
  $('#' + ControlId).replaceWith(newObject);
  }