
$(document).ready(function () {
    //init controls, Yes/No show on yes or show on no, trigger control, controls to show/hide
    showHideDetails("Yes","govc_driverslicenserequired","govc_driverslicenserequired");
    showHideDetails("Yes","govc_requireofficialregistrationdetails","govc_requireofficialregistrationdetails");     
    $('#govc_htmllabel2').parent().parent().html('{{snippets["Job Application Prereqs Content"]}}');
    //remove * from fields, as this is readonly we dont need them
    $("#govc_title_label").parent().removeClass("required");
    $("#govc_minimumqualification_label").parent().removeClass("required");
    });
       
    //show on yes or show on no, trigger control, controls to show/hide, accepts comma-seperated list for multiple controls
    function showHideDetails(onYes,optionControlId,detailsControlId) {
      
        //is trigger control set to yes or no?
        var selVal = $('#' + optionControlId).find("option:selected").text();
        //for each destination control
        $.each(detailsControlId.split(','), function(index,ctrl) {      
            //if checked
            if (selVal === onYes) {           
            $('#' + ctrl).parent().parent().show();
            }
            else {
            $('#' + ctrl).parent().parent().hide();
            }
        });
    }