$(document).ready(function () {
//could add check also against vacancy stage aswell as closing date
closingDate = new Date($('#govc_applicationclosingdate').val());
if (closingDate < new Date())
{
  $('#NextButton').val("Vacancy not accepting applications");
  $('#NextButton').prop('disabled', true)
}

//only if vacancy reference no field is populated
varVacancyRefNo = $('#govc_referenceno').val();
if (varVacancyRefNo != null)
{
    SwapTextForLabel("govc_requirementsdescription");
    SwapTextForLabel("govc_jobpurpose");
    SwapTextForLabel("govc_keyperformanceareas");
}

//remove * from fields, as this is readonly we dont need them
$("#govc_requirementsdescription_label").parent().removeClass("required");
$("#govc_title_label").parent().removeClass("required");
$("#govc_referenceno_label").parent().removeClass("required");
$("#govc_minimumqualification_label").parent().removeClass("required");

});


//change textarea to label for better UX
function SwapTextForLabel(ControlId) {
  var newObject = document.createElement('label');
  newObject.textContent =  $('#' + ControlId).val();
  $('#' + ControlId).replaceWith(newObject);
  }