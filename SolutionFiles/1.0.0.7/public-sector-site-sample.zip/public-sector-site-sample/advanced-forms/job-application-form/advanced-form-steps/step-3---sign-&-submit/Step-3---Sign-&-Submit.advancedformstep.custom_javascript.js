//hide the labels for signature title, could have done with CSS also
//$(document).ready(function () {
//    $("div[data-name='Signature_Tab']").prev("h2.tab-title").hide();
//});
var signaturePad;

//helper function to properly size canvas
function resizeCanvas() {
    let canvas = document.getElementById("SignatureCanvas");
    let ratio =  Math.max(window.devicePixelRatio || 1, 1);
    canvas.width = canvas.offsetWidth * ratio;
    canvas.height = canvas.offsetHeight * ratio;
    canvas.getContext("2d").scale(ratio, ratio);
    signaturePad.clear(); // otherwise isEmpty() might return incorrect value
}

window.addEventListener("resize", resizeCanvas);

$(document).ready(function() {

    //hide signature sectoin title
    $("div[data-name='Signature_Tab']").prev("h2.tab-title").hide();

    // name of you signature text field
    let signatureTextFieldName = "govc_signature";
    // main container
    let signatureContainer = document.createElement("div");

    // container for action buttons
    let signatureActionButtons = document.createElement("div");

    // Clear signature button
    let clearBtn = document.createElement("button");
    clearBtn.innerText = "Clear";
    clearBtn.type = "button";
    clearBtn.addEventListener("click", () => {
        signaturePad.clear();
        $("#"+signatureTextFieldName).val();
    }); 

    // Undo last action
    let undoBtn = document.createElement("button");
    undoBtn.innerText = "Undo";
    undoBtn.type = "button";
    undoBtn.addEventListener("click", () => {
        let data = signaturePad.toData();

        if (data) {
          data.pop(); // remove the last dot or line
          signaturePad.fromData(data);
          $("#"+signatureTextFieldName).val(signaturePad.toDataURL());
        }
    }); 

    signatureActionButtons.appendChild(undoBtn);
    signatureActionButtons.appendChild(clearBtn);

    let canvas = document.createElement("canvas");
    canvas.id = "SignatureCanvas";
    canvas.style.width = "100%";
    canvas.style.border = "1px solid";

    signatureContainer.appendChild(canvas);
    signatureContainer.appendChild(signatureActionButtons);

    // Get div wrapper of text signature field
    let wrapperTextSignature = $("#"+signatureTextFieldName).parent();
    // Insert our signature container after original wrapper field
    $(signatureContainer).insertAfter(wrapperTextSignature);
    // Hide original field
    wrapperTextSignature.hide();
    
    // Initialize Signature Pad
    signaturePad = new SignaturePad(canvas, {
        //save signature every time the user ends stroke
        onEnd: () => $("#"+signatureTextFieldName).val(signaturePad.toDataURL())
    });

    resizeCanvas();
});