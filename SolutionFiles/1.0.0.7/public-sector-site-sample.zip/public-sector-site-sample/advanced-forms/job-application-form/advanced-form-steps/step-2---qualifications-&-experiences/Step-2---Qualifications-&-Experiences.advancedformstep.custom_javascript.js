$(document).ready(function () {
    $("div[data-name='Qualifications_Tab']").prev("h2.tab-title").hide();//hide the labels for qualification title
   // $('#govc_ahtmllabel1').parent().parent().parent().hide();//hide htmllabel1 element
    attachRequiredValidator("govc_languageprofiency","Language Proficiency");
    attachRequiredValidator("govc_qualification","Qualification");
    attachRequiredValidator("govc_workexperience","Work Experience");
    attachRequiredValidator("govc_jobreference","Reference");    
});

 function attachRequiredValidator(targetElementId,sectionName) { 
            if(typeof Page_Validators == 'undefined' || !Page_Validators) {
                return;
            }
            
            var requiredValidator = document.createElement("span");           
            requiredValidator.style.display = "none";  
            requiredValidator.id = "RequiredValidator" + targetElementId;   
            requiredValidator.controltovalidate = targetElementId;
            requiredValidator.errormessage = "<a href=''>At least one " + sectionName + " is required " +"</a>";
            requiredValidator.evaluationfunction = function() {
                //$("#Language_Subgrid div.view-grid > table > tbody > tr[data-entity='govc_languageprofiency']").length
                var numRows = $("tr[data-entity='" + targetElementId + "']").length;
                //alert(numRows);
                //could at test for max rows too, might not want too many
                if (numRows > 0) {
                    return true;
                }                    
                return false;
            };  
         
            Page_Validators.push(requiredValidator);  
        }

