
$(document).ready(function () {


checkVacancyCloseDate();


//init controls, Yes/No show on yes or show on no, trigger control, controls to show/hide
showHideDetails("Yes","govc_pastcriminaloffice","govc_criminaloffencedetails");
showHideDetails("Yes","govc_pendingcriminalcase","govc_pendingcasedetails");
showHideDetails("Yes","govc_dismissedfrompublicservice","govc_dismissedfrompublicservicedetails");
showHideDetails("Yes","govc_pendingdisciplinarycase","govc_pendingdisciplinarycasedetails");
showHideDetails("Yes","govc_resignedpendingdisciplinary","govc_resignedpendingdisciplinarydetails");
showHideDetails("Yes","govc_retiredduetohealth","govc_retiredduetohealthdetails");
showHideDetails("Yes","govc_businesswithstate","govc_businesswithstatedetails");
showHideDetails("No","govc_zacitizen","govc_nationality,govc_validworkpermit");
showHideDetails("Yes","govc_publicservicereappointmentconditions","govc_conditiondeptname,govc_natureofconditionreappointment");

contactInfoRequiredFields();
officalRegistrationFields();

//register change events
     $("#govc_pastcriminaloffice").change("govc_criminaloffencedetails",onOptChangeYes);
     $("#govc_pendingcriminalcase").change("govc_pendingcasedetails",onOptChangeYes);
     $("#govc_dismissedfrompublicservice").change("govc_dismissedfrompublicservicedetails",onOptChangeYes);
     $("#govc_pendingdisciplinarycase").change("govc_pendingdisciplinarycasedetails",onOptChangeYes);
     $("#govc_resignedpendingdisciplinary").change("govc_resignedpendingdisciplinarydetails",onOptChangeYes);
     $("#govc_retiredduetohealth").change("govc_retiredduetohealthdetails",onOptChangeYes);
     $("#govc_businesswithstate").change("govc_businesswithstatedetails",onOptChangeYes);
     $("#govc_zacitizen").change("govc_nationality,govc_validworkpermit",onOptChangeNo);
     $("#govc_publicservicereappointmentconditions").change("govc_conditiondeptname,govc_natureofconditionreappointment",onOptChangeYes);
     $("#govc_preferredcorrespondencemethod").change(contactInfoRequiredFields);
     
});

//if trigger on yes
function onOptChangeYes(e)
{
    //send id of control which caused event, and details control to hide, Show on Yes
    showHideDetails("Yes",e.target.id,e.data);
}

//if trigger on no
function onOptChangeNo(e)
{
    //send id of control which caused event, and details control to hide, show on No
    showHideDetails("No",e.target.id,e.data);
}

//show on yes or show on no, trigger control, controls to show/hide, accepts comma-seperated list for multiple controls
function showHideDetails(onYes,optionControlId,detailsControlId) {
  
    //is trigger control set to yes or no?
    var selVal = $('#' + optionControlId).find("option:selected").text();
    //for each destination control
    $.each(detailsControlId.split(','), function(index,ctrl) {      
        //if checked
        if (selVal === onYes) {           
        $('#' + ctrl).parent().parent().show();
        }
        else {
        $('#' + ctrl).parent().parent().hide();
        }
    });

   
}

function officalRegistrationFields()
{

//hide requiredofficialfields toggle field, use this value later to determine if to make those fields required.
$('#govc_requireofficialregistrationdetails').parent().parent().parent().hide(); //hide tr which control sits in
     var selVal = $('#govc_requireofficialregistrationdetails').find("option:selected").text();
     if (selVal == "Yes")
     {
         attachRequiredValidator('govc_officialregistrationdate');
         attachRequiredValidator('govc_officialregistrationinstitution');
         attachRequiredValidator('govc_officialregistrationregno');
     }


}

//if preffered method is email, email is required, it telephone, telephone is required
function contactInfoRequiredFields()
{

    var selVal = $('#govc_preferredcorrespondencemethod').find("option:selected").text();
    if(selVal== "Email")
    {
        attachRequiredValidator('govc_email');
        removeRequiredValidator('govc_telephonenumber');

    }
    else if(selVal== "Telephone")
    {
        attachRequiredValidator('govc_telephonenumber');
        removeRequiredValidator('govc_email');
    }
    
}

function checkVacancyCloseDate()
{

$('#govc_applicationclosingdate').parent().parent().parent().hide();
$('#govc_vacancystage').parent().parent().parent().hide();

//could add check also against vacancy stage aswell as closing date
//also check if there is a source job being applied for
closingDate = new Date($('#govc_applicationclosingdate').val());
if ((closingDate < new Date()) || $('#govc_referenceno').length == 0)
{
  $('#NextButton').val("We are no longer accepting applications for this job");
  $('#NextButton').prop('disabled', true);
  $('#EntityFormView').hide();
}
}

//field passed in becomes required
function attachRequiredValidator(targetElementId) { 
    if(typeof Page_Validators == 'undefined' || !Page_Validators) {
        return;
    }
    var requiredValidator = document.createElement("span");  
           
    requiredValidator.style.display = "none";  
    requiredValidator.id = "RequiredValidator" + targetElementId;   
    requiredValidator.controltovalidate = targetElementId;
    requiredValidator.errormessage = "<a href='#" + targetElementId + "'>" + $("#" + targetElementId + "_label").text() + " is a required field</a>";
    requiredValidator.evaluationfunction = function() {
        var inputVal = $("#" + targetElementId).val();        
        if (inputVal === "") {
            return false;
        }            
        return true;
    };  
 
    Page_Validators.push(requiredValidator); 

    $("a[href='#"+ targetElementId + "_label']").on("click", function() {  
        scrollToAndFocus(targetElementId + "_label", targetElementId);  
    }); 

    $("#"+ targetElementId + "_label").parent().addClass("required");

}

//field passed in, is not required
function removeRequiredValidator(fieldId) {
    for (var i = 0; i < Page_Validators.length; i++) {
        if (Page_Validators[i].id == "RequiredValidator" + fieldId) {
            Page_Validators.splice(i, 1);
            $("#"+ fieldId + "_label").parent().removeClass("required");

            break;
        }
    }
}